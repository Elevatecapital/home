# Elevate iYield Templates

1. Install the jekyll and bundler gems if you don't have them already `gem install jekyll bundler`
2. Clone this repo and run `bundle install`
3. Run `bundle exec jekyll serve`

### Adding a template

1. Create a new HTML file in the root directoy
2. Make sure you add a frontloading comment with a layout defined at the top of the new file (see `index.html` for an example).
